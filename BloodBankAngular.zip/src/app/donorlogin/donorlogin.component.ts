import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { BloodbankService } from '../bloodbank.service';

@Component({
  selector: 'app-donorlogin',
  templateUrl: './donorlogin.component.html',
  styleUrls: ['./donorlogin.component.css']
})
export class DonorloginComponent implements OnInit {

  constructor(private ps:BloodbankService, private route:Router) {
  }
  insertLoginDonor(insert1:any){
   this.ps.insertLoginDonor1(insert1.value).subscribe(response=>{
     alert("Login Successfull!!");
     sessionStorage.setItem('loggedInUserDetails',JSON.stringify(response))
     console.log(sessionStorage.getItem('loggedInUserDetails'));
     // console.log(JSON.parse(sessionStorage.getItem('loggedInUserDetails')));      
     this.route.navigate(['donornavi']);
     
   },error=>alert("Invalid Credentials!! Please try again"));
  }
  ngOnInit(): void {
  }

}
