import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NeedbloodComponent } from './needblood.component';

describe('NeedbloodComponent', () => {
  let component: NeedbloodComponent;
  let fixture: ComponentFixture<NeedbloodComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ NeedbloodComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(NeedbloodComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
