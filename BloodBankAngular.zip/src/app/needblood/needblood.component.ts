import { Component, OnInit } from '@angular/core';
import { BloodbankService } from '../bloodbank.service';

@Component({
  selector: 'app-needblood',
  templateUrl: './needblood.component.html',
  styleUrls: ['./needblood.component.css']
})
export class NeedbloodComponent implements OnInit {

  constructor(private ps:BloodbankService) { 
  }
  insertNeedblood12(insertNeedblood:any){
      this.ps.insertNeedblood1(insertNeedblood.value).subscribe(response=>{
        alert("Need Blood Successfull!!");
      },error=>alert("Need Blood not successfull!! Please try again"));
    }

  ngOnInit(): void {
  }

}
