import { Component, OnInit } from '@angular/core';
import { BloodbankService } from '../bloodbank.service';

@Component({
  selector: 'app-addappointment',
  templateUrl: './addappointment.component.html',
  styleUrls: ['./addappointment.component.css']
})
export class AddappointmentComponent implements OnInit {

  constructor(private ps:BloodbankService) { 
  }
  insertAddappointment(insertaddappointment:any){
    console.log(insertaddappointment);
      this.ps.insertAddappointment1(insertaddappointment.value).subscribe(response=>{
        alert("Add Appointment Successfull!!");
      },error=>alert("Add Appointment not successfull!! Please try again"));
    }

  ngOnInit(): void {
  }

}
