import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { BloodbankService } from '../bloodbank.service';

@Component({
  selector: 'app-buyerlogin',
  templateUrl: './buyerlogin.component.html',
  styleUrls: ['./buyerlogin.component.css']
})
export class BuyerloginComponent implements OnInit {

  constructor(private ps:BloodbankService, private route:Router) {
  }
  insertLoginBuyer(insert1:any){
   this.ps.insertLoginBuyer1(insert1.value).subscribe(response=>{
     alert("Login Successfull!!");
     sessionStorage.setItem('loggedInUserDetails',JSON.stringify(response))
     console.log(sessionStorage.getItem('loggedInUserDetails'));
     // console.log(JSON.parse(sessionStorage.getItem('loggedInUserDetails')));      
     this.route.navigate(['buyernavi']);
     
   },error=>alert("Invalid Credentials!! Please try again"));
  }

  ngOnInit(): void {
  }

}
