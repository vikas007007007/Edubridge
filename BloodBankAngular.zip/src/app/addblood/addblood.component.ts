import { Component, OnInit } from '@angular/core';
import { BloodbankService } from '../bloodbank.service';

@Component({
  selector: 'app-addblood',
  templateUrl: './addblood.component.html',
  styleUrls: ['./addblood.component.css']
})
export class AddbloodComponent implements OnInit {

  constructor(private ps:BloodbankService) { 
  }
  insertAddblood(insert1:any){
      this.ps.insertAddblood1(insert1.value).subscribe(response=>{
        alert("Add Blood Successfull!!");
      },error=>alert("Add Blood not successfull!! Please try again"));
    }

  ngOnInit(): void {
  }

}
