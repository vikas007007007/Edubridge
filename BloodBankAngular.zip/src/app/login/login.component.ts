import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { BloodbankService } from '../bloodbank.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private ps:BloodbankService, private route:Router) {
  }
  insertLoginAdmin(insert1:any){
   this.ps.insertLoginAdmin1(insert1.value).subscribe(response=>{
     alert("Login Successfull!!");
     sessionStorage.setItem('loggedInUserDetails',JSON.stringify(response))
     console.log(sessionStorage.getItem('loggedInUserDetails'));
     // console.log(JSON.parse(sessionStorage.getItem('loggedInUserDetails')));      
     this.route.navigate(['adminnavi']);
     
   },error=>alert("Invalid Credentials!! Please try again"));
 }

  ngOnInit(): void {
  }

}
