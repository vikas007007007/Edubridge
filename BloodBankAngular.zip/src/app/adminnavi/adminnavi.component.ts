import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-adminnavi',
  templateUrl: './adminnavi.component.html',
  styleUrls: ['./adminnavi.component.css']
})
export class AdminnaviComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
