import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AddappointmentComponent } from './addappointment/addappointment.component';
import { AddbloodComponent } from './addblood/addblood.component';
import { AddbuyerdetailsComponent } from './addbuyerdetails/addbuyerdetails.component';
import { AdddonorComponent } from './adddonor/adddonor.component';
import { AdminnaviComponent } from './adminnavi/adminnavi.component';
import { BuyerloginComponent } from './buyerlogin/buyerlogin.component';
import { BuyernaviComponent } from './buyernavi/buyernavi.component';
import { ContactusComponent } from './contactus/contactus.component';
import { DonorloginComponent } from './donorlogin/donorlogin.component';
import { DonornaviComponent } from './donornavi/donornavi.component';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { NavigationComponent } from './navigation/navigation.component';
import { NeedbloodComponent } from './needblood/needblood.component';
import { RegisterComponent } from './register/register.component';
import { ViewappointmentComponent } from './viewappointment/viewappointment.component';
import { ViewbloodComponent } from './viewblood/viewblood.component';
import { ViewbuyerComponent } from './viewbuyer/viewbuyer.component';

const routes: Routes = [
  {path:'adminlogin',component:LoginComponent},
  {path:'addblood',component:AddbloodComponent},
  {path:'viewblood',component:ViewbloodComponent},
  {path:'needblood',component:NeedbloodComponent},
  {path:'adddonor',component:AdddonorComponent},
  {path:'addappointment',component:AddappointmentComponent},
  {path:'home',component:NavigationComponent},
  {path:'addbuyerdetails',component:AddbuyerdetailsComponent},
  {path:'viewappointment',component:ViewappointmentComponent},
  {path:'viewbuyer',component:ViewbuyerComponent},
  {path:'register',component:RegisterComponent},
  {path:'adminnavi',component:AdminnaviComponent},
  {path:'donornavi',component:DonornaviComponent},
  {path:'buyerlogin',component:BuyerloginComponent},
  {path:'donorlogin',component:DonorloginComponent},
  {path:'buyernavi',component:BuyernaviComponent},
  {path:'addbuyerdetails',component:AddbuyerdetailsComponent},
  {path:'contactus',component:ContactusComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
