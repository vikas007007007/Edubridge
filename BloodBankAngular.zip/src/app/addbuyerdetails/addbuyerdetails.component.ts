import { Component, OnInit } from '@angular/core';
import { BloodbankService } from '../bloodbank.service';

@Component({
  selector: 'app-addbuyerdetails',
  templateUrl: './addbuyerdetails.component.html',
  styleUrls: ['./addbuyerdetails.component.css']
})
export class AddbuyerdetailsComponent implements OnInit {

  constructor(private ps:BloodbankService) { 
  }
  insertAddbuyerdetails(addbuyerdetails:any){
    console.log(addbuyerdetails);
      this.ps.insertAddbuyerdetails1(addbuyerdetails.value).subscribe(response=>{
        alert("Add Buyer Successfull!!");
      },error=>alert("Add Buyer not successfull!! Please try again"));
    }

  ngOnInit(): void {
  }

}
