import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddbuyerdetailsComponent } from './addbuyerdetails.component';

describe('AddbuyerdetailsComponent', () => {
  let component: AddbuyerdetailsComponent;
  let fixture: ComponentFixture<AddbuyerdetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddbuyerdetailsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AddbuyerdetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
