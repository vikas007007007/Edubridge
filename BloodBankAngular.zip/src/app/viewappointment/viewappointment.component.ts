import { Component, OnInit } from '@angular/core';
import { BloodbankService } from '../bloodbank.service';

@Component({
  selector: 'app-viewappointment',
  templateUrl: './viewappointment.component.html',
  styleUrls: ['./viewappointment.component.css']
})
export class ViewappointmentComponent implements OnInit {

  constructor(private ps:BloodbankService) {
    this.viewAppointments();
   }
   appointment:any 
   viewAppointments(){
    this.ps.viewAppointments().subscribe((result:any)=>{this.appointment=result});
  }

  ngOnInit(): void {
  }

}
