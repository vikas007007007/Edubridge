import { Component, OnInit } from '@angular/core';
import { BloodbankService } from '../bloodbank.service';

@Component({
  selector: 'app-viewbuyer',
  templateUrl: './viewbuyer.component.html',
  styleUrls: ['./viewbuyer.component.css']
})
export class ViewbuyerComponent implements OnInit {

  constructor(private ps:BloodbankService) {
    this.viewBuyers();
   }
   buyers:any 
   viewBuyers(){
    this.ps.viewBuyers().subscribe((result:any)=>{this.buyers=result});
  }

  ngOnInit(): void {
  }

}
