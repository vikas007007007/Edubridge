import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DonornaviComponent } from './donornavi.component';

describe('DonornaviComponent', () => {
  let component: DonornaviComponent;
  let fixture: ComponentFixture<DonornaviComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DonornaviComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(DonornaviComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
