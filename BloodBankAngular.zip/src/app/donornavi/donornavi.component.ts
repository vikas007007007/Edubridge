import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-donornavi',
  templateUrl: './donornavi.component.html',
  styleUrls: ['./donornavi.component.css']
})
export class DonornaviComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
