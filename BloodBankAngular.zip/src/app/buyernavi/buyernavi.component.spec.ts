import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BuyernaviComponent } from './buyernavi.component';

describe('BuyernaviComponent', () => {
  let component: BuyernaviComponent;
  let fixture: ComponentFixture<BuyernaviComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BuyernaviComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(BuyernaviComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
