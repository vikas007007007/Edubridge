import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-buyernavi',
  templateUrl: './buyernavi.component.html',
  styleUrls: ['./buyernavi.component.css']
})
export class BuyernaviComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
