import { Component, OnInit } from '@angular/core';
import { BloodbankService } from '../bloodbank.service';

@Component({
  selector: 'app-adddonor',
  templateUrl: './adddonor.component.html',
  styleUrls: ['./adddonor.component.css']
})
export class AdddonorComponent implements OnInit {

  constructor(private ps:BloodbankService) { 
  }
  insertAdddonor(adddonor:any){
      this.ps.insertAdddonor1(adddonor.value).subscribe(response=>{
        alert("Add Buyer Successfull!!");
      },error=>alert("Add Buyer not successfull!! Please try again"));
    }

  ngOnInit(): void {
  }

}
