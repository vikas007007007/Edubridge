import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { BloodbankService } from '../bloodbank.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  constructor(private ps:BloodbankService, private router:Router) { }

  insertRegister(insertregister:any){
    console.log(insertregister.value);
    this.ps.insertRegister1(insertregister.value).subscribe(response=>{
      
      alert("Registration Successfull!!");
      this.router.navigate(['home']);
    },error=>alert("Registration not successfull!! Please try again"));
  }
  ngOnInit(): void {
  }

}
