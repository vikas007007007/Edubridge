import { Component, OnInit } from '@angular/core';
import { BloodbankService } from '../bloodbank.service';

@Component({
  selector: 'app-contactus',
  templateUrl: './contactus.component.html',
  styleUrls: ['./contactus.component.css']
})
export class ContactusComponent implements OnInit {

  constructor(private ps:BloodbankService) { 
  }
    insertContact(insertcontact:any){
      this.ps.insertContact1(insertcontact.value).subscribe(response=>{
        alert("Add Contact Successfull!!");
      },error=>alert("Add Contact not successfull!! Please try again"));
    }

  ngOnInit(): void {
  }

}
