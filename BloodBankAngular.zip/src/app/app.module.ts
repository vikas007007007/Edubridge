import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NavigationComponent } from './navigation/navigation.component';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { BuyerloginComponent } from './buyerlogin/buyerlogin.component';
import { DonorloginComponent } from './donorlogin/donorlogin.component';
import { RegisterComponent } from './register/register.component';
import { ContactusComponent } from './contactus/contactus.component';
import { AdminnaviComponent } from './adminnavi/adminnavi.component';
import { DonornaviComponent } from './donornavi/donornavi.component';
import { BuyernaviComponent } from './buyernavi/buyernavi.component';
import { FooterComponent } from './footer/footer.component';
import { AddappointmentComponent } from './addappointment/addappointment.component';
import { AddbloodComponent } from './addblood/addblood.component';
import { ViewappointmentComponent } from './viewappointment/viewappointment.component';
import { ViewbuyerComponent } from './viewbuyer/viewbuyer.component';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { AddbuyerdetailsComponent } from './addbuyerdetails/addbuyerdetails.component';
import { ViewbloodComponent } from './viewblood/viewblood.component';
import { NeedbloodComponent } from './needblood/needblood.component';
import { AdddonorComponent } from './adddonor/adddonor.component';

@NgModule({
  declarations: [
    AppComponent,
    NavigationComponent,
    HomeComponent,
    LoginComponent,
    BuyerloginComponent,
    DonorloginComponent,
    RegisterComponent,
    ContactusComponent,
    AdminnaviComponent,
    DonornaviComponent,
    BuyernaviComponent,
    FooterComponent,
    AddappointmentComponent,
    AddbloodComponent,
    ViewappointmentComponent,
    ViewbuyerComponent,
    AddbuyerdetailsComponent,
    ViewbloodComponent,
    NeedbloodComponent,
    AdddonorComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    FormsModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
