import { Component, OnInit } from '@angular/core';
import { BloodbankService } from '../bloodbank.service';

@Component({
  selector: 'app-viewblood',
  templateUrl: './viewblood.component.html',
  styleUrls: ['./viewblood.component.css']
})
export class ViewbloodComponent implements OnInit {

  constructor(private ps:BloodbankService) {
    this.viewBlood();
   }
   viewblood:any 
   viewBlood(){
    this.ps.viewBloods().subscribe((result:any)=>{this.viewblood=result});
  }

  ngOnInit(): void {
  }

}
