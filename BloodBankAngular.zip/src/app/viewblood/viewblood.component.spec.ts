import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewbloodComponent } from './viewblood.component';

describe('ViewbloodComponent', () => {
  let component: ViewbloodComponent;
  let fixture: ComponentFixture<ViewbloodComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ViewbloodComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ViewbloodComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
