import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class BloodbankService {

  url1 = "http://localhost:8080/insertContact"
  url2 = "http://localhost:8080/insertLoginAdmin1"
  url3 = "http://localhost:8080/insertRegister1"
  url4 = "http://localhost:8080/insertLoginDonor1"
  url5 = "http://localhost:8080/insertLoginBuyer1"
  url6 = "http://localhost:8080/insertAddblood1"
  url7 = "http://localhost:8080/insertAddappointment1"
  url8 = "http://localhost:8080/insertAddbuyerdetails1"
  url9 = "http://localhost:8080/viewBuyers"
  url10 = "http://localhost:8080/viewAppointments"
  url11 = "http://localhost:8080/viewBloods"
  url12 = "http://localhost:8080/insertNeedblood"
  url13 = "http://localhost:8080/insertAdddonor"
  
  constructor(private h1: HttpClient) {

  }


  insertContact1(data: any) {
    return this.h1.post(this.url1, data); //post belonging to httpclient

  }
  insertLoginAdmin1(data: any) {
   
    return this.h1.post(this.url2, data); //post belonging to httpclient

  }
  insertRegister1(data: any) {
    return this.h1.post(this.url3, data); //post belonging to httpclient

  }
  insertLoginDonor1(data: any) {
    return this.h1.post(this.url4, data); //post belonging to httpclient

  }
  insertLoginBuyer1(data: any) {
    return this.h1.post(this.url5, data); //post belonging to httpclient

  }
  insertAddblood1(data: any) {
    return this.h1.post(this.url6, data); //post belonging to httpclient

  }
  insertAddappointment1(data: any) {
    return this.h1.post(this.url7, data); //post belonging to httpclient

  }
  insertAddbuyerdetails1(data: any) {
    return this.h1.post(this.url8, data); //post belonging to httpclient

  }
  insertNeedblood1(data: any) {
    console.log(data);
    return this.h1.post(this.url12, data); //post belonging to httpclient

  }
  insertAdddonor1(data: any) {
    return this.h1.post(this.url13, data); //post belonging to httpclient

  }
  viewBuyers() {
    return this.h1.get(this.url9);
  }
  viewAppointments() {
    return this.h1.get(this.url10);
  }
  viewBloods() {
    return this.h1.get(this.url11);
  }

 
}
