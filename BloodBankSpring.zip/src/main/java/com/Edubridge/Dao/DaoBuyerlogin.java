package com.Edubridge.Dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.Edubridge.BloodbankAdminlogin;
import com.Edubridge.BloodbankBuyerlogin;

public interface DaoBuyerlogin extends JpaRepository<BloodbankBuyerlogin,Integer> {

	BloodbankBuyerlogin findByEmail(String email);

}
