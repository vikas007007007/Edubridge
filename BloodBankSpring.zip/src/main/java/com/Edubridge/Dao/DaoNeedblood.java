package com.Edubridge.Dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.Edubridge.BloodbankAddbuyer;
import com.Edubridge.BloodbankNeedblood;

public interface DaoNeedblood extends JpaRepository<BloodbankNeedblood,Integer> {

}
