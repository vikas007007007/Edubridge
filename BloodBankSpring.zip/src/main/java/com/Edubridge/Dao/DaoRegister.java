package com.Edubridge.Dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.Edubridge.BloodbankRegister;

public interface DaoRegister extends JpaRepository<BloodbankRegister,String>{

	BloodbankRegister findByEmail(String email);

}
