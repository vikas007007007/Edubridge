package com.Edubridge.Dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.Edubridge.BloodbankAddblood;

public interface DaoAddblood extends JpaRepository<BloodbankAddblood,Integer> {

}
