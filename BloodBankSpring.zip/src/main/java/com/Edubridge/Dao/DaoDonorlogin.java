package com.Edubridge.Dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.Edubridge.BloodbankBuyerlogin;
import com.Edubridge.Bloodbankdonorlogin;

public interface DaoDonorlogin extends JpaRepository<Bloodbankdonorlogin,Integer> {

	Bloodbankdonorlogin findByEmail(String email);

}
