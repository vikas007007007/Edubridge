package com.Edubridge.Dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.Edubridge.BloodbankAddappointment;
import com.Edubridge.BloodbankAddblood;

public interface DaoAddappointment extends JpaRepository<BloodbankAddappointment,Integer> {

}
