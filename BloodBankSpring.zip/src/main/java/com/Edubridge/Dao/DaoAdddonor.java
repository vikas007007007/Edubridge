package com.Edubridge.Dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.Edubridge.BloodbankAddbuyer;
import com.Edubridge.BloodbankAdddonor;

public interface DaoAdddonor extends JpaRepository<BloodbankAdddonor,Integer> {

}
