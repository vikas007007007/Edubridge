package com.Edubridge.Dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.Edubridge.BloodbankAdminlogin;

public interface DaoAdminlogin extends JpaRepository<BloodbankAdminlogin,Integer> {

	BloodbankAdminlogin findByEmail(String email);


}
