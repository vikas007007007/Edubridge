package com.Edubridge.Dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.Edubridge.BloodbankAddblood;
import com.Edubridge.BloodbankAddbuyer;

public interface DaoAddbuyer extends JpaRepository<BloodbankAddbuyer,Integer> {

}
