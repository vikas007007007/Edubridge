package com.Edubridge.Dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.Edubridge.BloodbankAddblood;
import com.Edubridge.BloodbankContactus;

public interface DaoContactus  extends JpaRepository<BloodbankContactus,Integer>{

}
