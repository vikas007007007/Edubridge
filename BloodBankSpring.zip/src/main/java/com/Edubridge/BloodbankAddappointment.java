package com.Edubridge;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class BloodbankAddappointment {
	@Id
	int id;
	String donorname;
	String phonenumber;
	String email;
	String address;
	String bloodgroup;
	String bloodtest;
	public BloodbankAddappointment() {

	}

	public BloodbankAddappointment(int id,String donorname,String phonenumber, String email
			,String address,String bloodgroup,String bloodtest) {
		super();
		this.id=id;
		this.donorname = donorname;
		this.phonenumber = phonenumber;
		this.email = email;
		this.address = address;
		this.bloodgroup = bloodgroup;
		this.bloodtest = bloodtest;
		
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getDonorname() {
		return donorname;
	}

	public void setDonorname(String donorname) {
		this.donorname = donorname;
	}

	public String getPhonenumber() {
		return phonenumber;
	}

	public void setPhonenumber(String phonenumber) {
		this.phonenumber = phonenumber;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getBloodgroup() {
		return bloodgroup;
	}

	public void setBloodgroup(String bloodgroup) {
		this.bloodgroup = bloodgroup;
	}

	public String getBloodtest() {
		return bloodtest;
	}

	public void setBloodtest(String bloodtest) {
		this.bloodtest = bloodtest;
	}

}
