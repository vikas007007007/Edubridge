package com.Edubridge;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class BloodbankAddblood {
	@Id
	int id;
	String bloodgroup;
	String units;
	public BloodbankAddblood() {

	}

	public BloodbankAddblood(int id,String bloodgroup,String units) {
		super();
		this.id=id;
		this.bloodgroup = bloodgroup;
		this.units = units;
		
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getBloodgroup() {
		return bloodgroup;
	}

	public void setBloodgroup(String bloodgroup) {
		this.bloodgroup = bloodgroup;
	}

	public String getUnits() {
		return units;
	}

	public void setUnits(String units) {
		this.units = units;
	}
	
	
}
