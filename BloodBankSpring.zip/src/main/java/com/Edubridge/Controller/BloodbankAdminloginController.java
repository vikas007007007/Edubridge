package com.Edubridge.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.Edubridge.BloodbankAdminlogin;
import com.Edubridge.BloodbankRegister;
import com.Edubridge.Dao.DaoAdminlogin;
import com.Edubridge.Dao.DaoRegister;

@RestController
@CrossOrigin(origins="http://localhost:4200")
public class BloodbankAdminloginController {
	@Autowired
	DaoRegister ps;
	
	@PostMapping("insertLoginAdmin1")
	public ResponseEntity<?> signInUser(@RequestBody BloodbankRegister signInEntityData) {
		BloodbankRegister signInObj=ps.findByEmail(signInEntityData.getEmail());
		if(signInObj.getPassword().equals(signInObj.getPassword()) && signInObj.getEmail().equals(signInObj.getEmail()))
			return ResponseEntity.ok(signInObj);
			return (ResponseEntity<?>) ResponseEntity.internalServerError();
		
	}
}
