package com.Edubridge.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.Edubridge.BloodbankAddappointment;
import com.Edubridge.BloodbankAddbuyer;
import com.Edubridge.Service.BloodbankAddappointmentService;
import com.Edubridge.Service.BloodbankAddbuyerService;

@RestController
@CrossOrigin(origins="http://localhost:4200")
public class BloodbankAddbuyerController {
	@Autowired
	BloodbankAddbuyerService cfs;
	
	@PostMapping("insertAddbuyerdetails1")
	public BloodbankAddbuyer savep(@RequestBody BloodbankAddbuyer p) {
		cfs.saveAddbuyer(p);
		return p;
	}
	
	
	@GetMapping("viewBuyers")
	public List<BloodbankAddbuyer> getAll() {
		return cfs.getAllBloodbankAddbuyer();
	}

	// get method for single player

	public BloodbankAddbuyer getp(@PathVariable int id) {
		return cfs.getBloodbankAddbuyer(id);

	}

}
