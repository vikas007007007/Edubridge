package com.Edubridge.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.Edubridge.BloodbankAddbuyer;
import com.Edubridge.BloodbankNeedblood;
import com.Edubridge.Service.BloodbankAddbuyerService;
import com.Edubridge.Service.BloodbankNeedbloodService;

@RestController
@CrossOrigin(origins="http://localhost:4200")
public class BloodbankNeedbloodController {
	@Autowired
	BloodbankNeedbloodService cfs;
	
	@PostMapping("insertNeedblood")
	public BloodbankNeedblood savep(@RequestBody BloodbankNeedblood p) {
		cfs.saveNeedblood(p);
		return p;
	}

}
