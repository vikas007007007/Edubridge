package com.Edubridge.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.Edubridge.BloodbankAddappointment;
import com.Edubridge.BloodbankAddblood;
import com.Edubridge.BloodbankAddbuyer;
import com.Edubridge.Service.BloodbankAddappointmentService;
import com.Edubridge.Service.BloodbankAddbloodService;

@RestController
@CrossOrigin(origins="http://localhost:4200")
public class BloodbankAddappointmentController {
	@Autowired
	BloodbankAddappointmentService cfs;
	
	@PostMapping("insertAddappointment1")
	public BloodbankAddappointment savep(@RequestBody BloodbankAddappointment p) {
		cfs.saveAddappointment(p);
		return p;
	}
	
	@GetMapping("viewAppointments")
	public List<BloodbankAddappointment> getAll() {
		return cfs.getAllBloodbankAddappointment();
	}

	// get method for single player

	public BloodbankAddappointment getp(@PathVariable int id) {
		return cfs.getBloodbankAddappointment(id);

	}

}
