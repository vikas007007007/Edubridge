package com.Edubridge.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.Edubridge.BloodbankRegister;
import com.Edubridge.Dao.DaoRegister;
import com.Edubridge.Service.BloodbankRegisterService;

@RestController
@CrossOrigin(origins="http://localhost:4200")
public class BloodbankRegisterController {
	@Autowired
	BloodbankRegisterService ps;
	
	@PostMapping("insertRegister1")
	public BloodbankRegister savep(@RequestBody BloodbankRegister p) {
		ps.saveRegister(p);
		return p;
	}

}
