package com.Edubridge.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.Edubridge.BloodbankAddblood;
import com.Edubridge.Service.BloodbankAddbloodService;

@RestController
@CrossOrigin(origins="http://localhost:4200")
public class BloodbankAddbloodController {
	@Autowired
	BloodbankAddbloodService cfs;
	
	@PostMapping("insertAddblood1")
	public BloodbankAddblood savep(@RequestBody BloodbankAddblood p) {
		cfs.saveAddblood(p);
		return p;
	}
	
	
	@GetMapping("viewBloods")
	public List<BloodbankAddblood> getAll() {
		return cfs.getBloodbankAddblood();
	}

	// get method for single player

	public BloodbankAddblood getp(@PathVariable int id) {
		return cfs.getBloodbankAddblood(id);

	}
}
