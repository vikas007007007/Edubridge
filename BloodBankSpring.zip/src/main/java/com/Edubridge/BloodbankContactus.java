package com.Edubridge;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class BloodbankContactus {
	@Id
	int id;
	String txtName;
	String txtEmail;
	String txtPhone;
	String txtMsg;
	public BloodbankContactus() {

	}

	public BloodbankContactus(int id,String txtName,String txtEmail, String txtPhone
			,String txtMsg) {
		super();
		this.id=id;
		this.txtName = txtName;
		this.txtEmail = txtEmail;
		this.txtPhone = txtPhone;
		this.txtMsg = txtMsg;
		
	}

}
