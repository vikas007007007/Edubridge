package com.Edubridge.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Edubridge.BloodbankAddbuyer;
import com.Edubridge.BloodbankNeedblood;
import com.Edubridge.Dao.DaoAddbuyer;
import com.Edubridge.Dao.DaoNeedblood;

@Service
public class BloodbankNeedbloodService {
	@Autowired
	DaoNeedblood dnb;

	public BloodbankNeedbloodService() {

	}

	// post or save student

	public void saveNeedblood(BloodbankNeedblood p) {
		dnb.save(p);

	}

}
