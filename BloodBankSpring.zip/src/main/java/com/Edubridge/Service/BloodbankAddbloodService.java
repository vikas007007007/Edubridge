package com.Edubridge.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Edubridge.BloodbankAddblood;
import com.Edubridge.Dao.DaoAddblood;

@Service
public class BloodbankAddbloodService {
	@Autowired
	DaoAddblood dcfp;

	public BloodbankAddbloodService() {

	}

	// post or save student

	public void saveAddblood(BloodbankAddblood p) {
		dcfp.save(p);

	}
	
	public List<BloodbankAddblood> getBloodbankAddblood() {
		return dcfp.findAll();
	}

	// Get player by id
	public BloodbankAddblood getBloodbankAddblood(int id) {
		return dcfp.getOne(id);
	}
	

}
