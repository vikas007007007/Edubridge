package com.Edubridge.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Edubridge.BloodbankAddblood;
import com.Edubridge.BloodbankAddbuyer;
import com.Edubridge.Dao.DaoAddblood;
import com.Edubridge.Dao.DaoAddbuyer;

@Service
public class BloodbankAddbuyerService {
	@Autowired
	DaoAddbuyer dcfp;

	public BloodbankAddbuyerService() {

	}

	// post or save student

	public void saveAddbuyer(BloodbankAddbuyer p) {
		dcfp.save(p);

	}
	
	public List<BloodbankAddbuyer> getAllBloodbankAddbuyer() {
		return dcfp.findAll();
	}

	// Get player by id
	public BloodbankAddbuyer getBloodbankAddbuyer(int id) {
		return dcfp.getOne(id);
	}
	

}
