package com.Edubridge.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Edubridge.BloodbankAddbuyer;
import com.Edubridge.BloodbankAdddonor;
import com.Edubridge.Dao.DaoAddbuyer;
import com.Edubridge.Dao.DaoAdddonor;

@Service
public class BloodbankAdddonorService {
	@Autowired
	DaoAdddonor dcfp;

	public BloodbankAdddonorService() {

	}

	// post or save student

	public void saveAdddonor(BloodbankAdddonor p) {
		dcfp.save(p);

	}

}
