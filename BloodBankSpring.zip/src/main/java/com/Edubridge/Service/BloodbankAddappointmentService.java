package com.Edubridge.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Edubridge.BloodbankAddappointment;
import com.Edubridge.BloodbankAddblood;
import com.Edubridge.BloodbankAddbuyer;
import com.Edubridge.Dao.DaoAddappointment;
import com.Edubridge.Dao.DaoAddblood;

@Service
public class BloodbankAddappointmentService {
	@Autowired
	DaoAddappointment dcfp;

	public BloodbankAddappointmentService() {

	}

	// post or save student

	public void saveAddappointment(BloodbankAddappointment p) {
		dcfp.save(p);

	}
	
	public List<BloodbankAddappointment> getAllBloodbankAddappointment() {
		return dcfp.findAll();
	}

	// Get player by id
	public BloodbankAddappointment getBloodbankAddappointment(int id) {
		return dcfp.getOne(id);
	}
	
}
