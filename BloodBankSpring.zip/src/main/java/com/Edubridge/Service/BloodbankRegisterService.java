package com.Edubridge.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Edubridge.BloodbankRegister;
import com.Edubridge.Dao.DaoRegister;

@Service
public class BloodbankRegisterService {
	@Autowired
	DaoRegister dcas;
	
	public BloodbankRegisterService() {

	}
	
	// post or save student
		public void saveRegister(BloodbankRegister p) {
			dcas.save(p);
		}

}
