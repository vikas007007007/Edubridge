package com.Edubridge.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Edubridge.BloodbankAddappointment;
import com.Edubridge.BloodbankContactus;
import com.Edubridge.Dao.DaoAddappointment;
import com.Edubridge.Dao.DaoContactus;

@Service
public class BloodbankContactusService {
	@Autowired
	DaoContactus dcfp;

	public BloodbankContactusService() {

	}

	// post or save student

	public void saveContactus(BloodbankContactus p) {
		dcfp.save(p);

	}

}
