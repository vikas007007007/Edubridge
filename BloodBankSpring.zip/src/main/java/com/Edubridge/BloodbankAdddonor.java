package com.Edubridge;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class BloodbankAdddonor {
	@Id
	int id;
	String donorname;
	String phonenumber;
	String email;
	String address;
	String bloodgroup;
	
	public BloodbankAdddonor() {

	}

	public BloodbankAdddonor(int id,String donorname,String phonenumber, String email
			,String address,String bloodgroup) {
		super();
		this.id=id;
		this.donorname = donorname;
		this.phonenumber = phonenumber;
		this.email = email;
		this.address = address;
		
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getDonorname() {
		return donorname;
	}

	public void setDonorname(String donorname) {
		this.donorname = donorname;
	}

	public String getPhonenumber() {
		return phonenumber;
	}

	public void setPhonenumber(String phonenumber) {
		this.phonenumber = phonenumber;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getBloodgroup() {
		return bloodgroup;
	}

	public void setBloodgroup(String bloodgroup) {
		this.bloodgroup = bloodgroup;
	}
	


}
