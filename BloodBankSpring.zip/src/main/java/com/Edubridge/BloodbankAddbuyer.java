package com.Edubridge;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class BloodbankAddbuyer {
	@Id
	int id;
	String buyername;
	String phonenumber;
	String email;
	String address;
	String bloodgroup;
	String date;
	int units;
	public BloodbankAddbuyer() {

	}

	public BloodbankAddbuyer(int id,String buyername,String phonenumber, String email
			,String address,String bloodgroup,String date,int units) {
		super();
		this.id=id;
		this.buyername = buyername;
		this.phonenumber = phonenumber;
		this.email = email;
		this.address = address;
		this.date = date;
		this.units = units;
		
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	

	public String getBuyername() {
		return buyername;
	}

	public void setBuyername(String buyername) {
		this.buyername = buyername;
	}

	public String getPhonenumber() {
		return phonenumber;
	}

	public void setPhonenumber(String phonenumber) {
		this.phonenumber = phonenumber;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getBloodgroup() {
		return bloodgroup;
	}

	public void setBloodgroup(String bloodgroup) {
		this.bloodgroup = bloodgroup;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public int getUnits() {
		return units;
	}

	public void setUnits(int units) {
		this.units = units;
	}
	
}
